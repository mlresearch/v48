This document describes RawDataAndPlots.xlsx

RawDataAndPlots.xlsx contains both the plots and the raw data
used in the paper: Data-Efficient Off-Policy Policy Evaluation
for Reinforcement Learning, which will appear at ICML 2016.

The spreadsheet has multiple pages. The first, "Legends" was
just used to add legends to plots so that the legends could
be cut and used separately in the paper. The data in this
page should be ignored.

The other pages provide the results for various domains,
including two that are not described in the paper: Mountain
Car and Gridworld p1p2. The mountain car results are
described in the extended abstract that will be presented
at the ICML 2016 workshop: Data-Efficient Machine Learning.
The Gridworld p1p2 domain is the Gridworld domain using the
policies \pi_1 and \pi_2 defined in Philip Thomas' PhD
thesis.

Each page of results has two blocks of numbers. The top left
block contains the average MSE for various numbers of trials.
The block on the top right contains the standard errors. There
is also a line labeled "TOP BAR"---the C++ code used to make
these results did not include the ascii symbols, and so
this line was copied over the top line to create the right
legends.

Lower down each page is a sequence of plots. The highest plot
contains all of the curves and a legend. All of the plots
beneath this first plot are the same as the first, but
with curves removed and perhaps the legend removed. The lower
plots are also sometimes resized for use in the paper.