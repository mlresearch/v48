#LibBandit

LibBandit is a C++ library designed for efficiently simulating multi-armed bandit algorithms.

Currently the following algorithms are implemented:
* UCB
* Optimally confident UCB
* Almost optimally confident UCB
* Thompson sampling (Gaussian prior)
* MOSS
* Finite-horizon Gittins index (Gaussian/Gaussian model/prior)
* An approximation of the finite-horizon Gittins index
* Bayesian optimal for two arms (Gaussian/Gaussian model/prior)

Defining new noise models is as simple as extending a base class and implementing the reward function.


##Compiling

You will need a C++11 compliant compiler such as g++ 4.8 or clang 5.

LibBandit uses the Scons build system. With this installed you should be able to compile all sources by typing `scons`


##Using the Library

LibBandit is easy to use. See the examples/ folder.





